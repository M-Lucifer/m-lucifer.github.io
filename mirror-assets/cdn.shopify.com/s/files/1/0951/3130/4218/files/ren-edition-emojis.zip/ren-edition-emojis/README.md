# The Renaissance Edition Emoji Pack

## Contents
- 33 custom emojis for Slack

## Installation Instructions
## https://slack.com/help/articles/206870177-Add-custom-emoji-and-aliases-to-your-workspace

## Emoji List
- :ren-alien:
- :ren-anton:
- :ren-birthday-card:
- :ren-birthday-dog:
- :ren-birthday:
- :ren-bug-1:
- :ren-bug-2:
- :ren-cake:
- :ren-cat1:
- :ren-cat2:
- :ren-clap:
- :ren-cup:
- :ren-dead:
- :ren-eyes:
- :ren-f:
- :ren-facepalm:
- :ren-fire:
- :ren-headless:
- :ren-heart-eyes:
- :ren-heart-purple:
- :ren-heart-purple2:
- :ren-heart:
- :ren-melted:
- :ren-ok:
- :ren-party:
- :ren-please:
- :ren-present:
- :ren-raising-hands:
- :ren-saluting:
- :ren-skull:
- :ren-sweat:
- :ren-tears-of-joy:
- :ren-thumbs-up: